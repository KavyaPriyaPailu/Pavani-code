import { Router } from '@angular/router';
import { OfferDataSource } from '../offers/offers.datasource';
import { Observable } from 'rxjs';
import { OfferService } from '../offer.service';
import { Offer } from 'src/app/models/offer';
import { HttpClient } from '@angular/common/http';
import { Component, NgZone, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators ,FormBuilder} from '@angular/forms';

@Component({
  selector: 'app-offer-detail-create',
  templateUrl: './offer-detail-create.component.html',
  styleUrls: ['./offer-detail-create.component.scss']  
})

export class OfferDetailCreateComponent implements OnInit {
  picker: any;
  picker1: any;
  shipmentNumber = /[0-9]{6}/;
  form: FormGroup = new FormGroup({});      
  displayedColumns = ["shipmentNumber", "price", "vehicleSize", "vehicleBuildUp","pickupLocationName", "pickupDateTime","deliveryLocationName","deliveryDateTime","loadDetail1","loadDetail2","loadDetail3","edit","delete"];
  constructor(private offerService: OfferService, public router: Router,
     private fb: FormBuilder){ 

      
     }
  offers: Observable<Offer[]>;
  ngOnInit() {

    this.form = this.fb.group({
      //shipmentNumber: ['', [Validators.required, Validators.pattern(this.shipmentNumber)]],
      Price: [null, [Validators.required]],
      Currency:  [null, [Validators.required]],
      vehiclesize:  [null, [Validators.required]],
      VehicleBuildUp: [null, [Validators.required]],
      PickupLocationName:  [null, [Validators.required]],
      PickupDateTime: [null, [Validators.required]],
      DeliveryLocationName: [null, [Validators.required]],
      DeliveryDateTime:  [null, [Validators.required]],
      LoadDetail1: [null],
      LoadDetail2: [null],
      LoadDetail3: [null],  
      shipmentNumber: ['', [Validators.required, Validators.minLength(4), Validators.maxLength(20), Validators.pattern('S[0-9]{6}-[0-9]{4}')]]
        })
      }

      
      resetForm(){
        this.form.reset();
      }

        saveDetails(form: any) {

          alert('SUCCESS!! :-)\n\n' + JSON.stringify(form.value, null, 4));
         this.offers = form.value
          console.log(this.offers)
        }

      
      
      
       
}
