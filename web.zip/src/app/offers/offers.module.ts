import { FlexLayoutModule } from '@angular/flex-layout';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OffersRoutingModule } from './offers-routing.module';
import { OffersComponent } from './offers/offers.component';
import { MatTableModule, MatIconModule, MatButtonModule, MatFormFieldModule } from '@angular/material';
import { MomentModule } from 'ngx-moment';
import { OfferDetailCreateComponent } from './offer-detail-create/offer-detail-create.component';
import { OfferDetailEditComponent } from './offer-detail-edit/offer-detail-edit.component';
import { ReactiveFormsModule , FormsModule} from '@angular/forms';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';


@NgModule({
  declarations: [OffersComponent, OfferDetailCreateComponent, OfferDetailEditComponent],
  imports: [
    CommonModule,
    OffersRoutingModule,
    FlexLayoutModule,
    MatTableModule,
    MatIconModule,
    MatButtonModule,
    FormsModule,
    ReactiveFormsModule,
    MatInputModule,
    MatFormFieldModule,
    MatDatepickerModule,
    MomentModule.forRoot(),
   
  ]
})
export class OffersModule { }
