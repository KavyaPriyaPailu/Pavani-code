using System.Collections.Generic;
using System.Threading.Tasks;
using api.Context;
using api.ViewModels;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace api.Services {
    public class OfferService : IOfferService
    {
        private readonly MyContext _context;

        public OfferService(MyContext myContext) 
        {
            _context = myContext;
        }

        public async Task<IEnumerable<OfferViewModel>> GetOffers()
        {
            var offers = await _context.Offers.Select(o => new OfferViewModel() {
                Id = o.Id,
                ShipmentNumber = o.ShipmentNumber,
                Currency = o.Currency,
                DeliveryDateTime = o.DeliveryDateTime,
                DeliveryLocationName = o.DeliveryLocationName,
                LoadDetail1 = o.LoadDetail1,
                LoadDetail2 = o.LoadDetail2,
                LoadDetail3 = o.LoadDetail3,
                PickupDateTime = o.PickupDateTime,
                PickupLocationName = o.PickupLocationName,
                Price = o.Price,
                VehicleBuildUp = o.VehicleBuildUp,
                VehicleSize = o.VehicleSize
            }).ToListAsync();

            return offers;
        }

        //  public async Task<bool> AddOffers( IOfferService obj)
        // {
        //     _context.Add(obj);
        //     _context.SaveChanges();
        //     //await GetOffers();
        //     return true;
        // }
    }
}