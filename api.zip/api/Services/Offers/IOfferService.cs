using System.Collections.Generic;
using System.Threading.Tasks;
using api.ViewModels;

namespace api.Services {
    public interface IOfferService 
    {
        Task<IEnumerable<OfferViewModel>> GetOffers();
       //Task<IEnumerable<OfferViewModel>> AddOffers(IOfferService obj);
        //Object type is different but unable to crack it. IOfferService is wrong.
    }
}