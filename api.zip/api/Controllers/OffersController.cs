using System.Threading.Tasks;
using api.Services;
using Microsoft.AspNetCore.Mvc;

namespace api {

    [Route("api/offers")]
    [ApiController]
    public class OffersController : ControllerBase
    {
        private readonly IOfferService _offerService;
        public OffersController(IOfferService offerService) 
        {
            _offerService = offerService;
        }

        [HttpGet]
        public async Task<ActionResult> GetOffers() 
        {
            var offers = await _offerService.GetOffers();
            return new OkObjectResult(offers);
        }

        // [HttpPost]
        // public async Task<ActionResult> AddOffers([FromBody] IOfferService obj) 
        // //Objecttype should be of IOfferService or OffersController need to check
        // {
        //     var offers = await _offerService.AddOffers(obj);
        //     return new OkObjectResult(offers);  
        // }
        
    }
}